
const music = document.getElementById("background-music");
const toggleMusicButton = document.getElementById("toggle-music");
const startButton = document.getElementById("start-button");
const questionContainer = document.getElementById("question-container");

const questions = [
    { question: "Quantos continentes existem?", answer: "7" },
    { question: "Qual é a capital da França?", answer: "Paris" },
    { question: "Quanto é 5 + 3?", answer: "8" },
];

let currentQuestionIndex = 0;
let score = 0;

// Música
window.onload = () => {
    music.play().catch(() => {
        console.log("O navegador bloqueou a reprodução automática.");
    });
};

toggleMusicButton.addEventListener("click", () => {
    if (music.paused) {
        music.play();
        toggleMusicButton.innerText = "🎵 Pausar Música";
    } else {
        music.pause();
        toggleMusicButton.innerText = "🎵 Retomar Música";
    }
});

// Jogo
startButton.addEventListener("click", () => {
    startButton.style.display = "none";
    showQuestion();
});

function showQuestion() {
    if (currentQuestionIndex < questions.length) {
        const q = questions[currentQuestionIndex];
        questionContainer.innerHTML = `
            <p>${q.question}</p>
            <input type="text" id="answer" placeholder="Sua resposta">
            <button onclick="checkAnswer()">Enviar</button>
        `;
    } else {
        questionContainer.innerHTML = `<p>Fim do jogo! Sua pontuação: ${score}/${questions.length}</p>`;
    }
}

function checkAnswer() {
    const answerInput = document.getElementById("answer");
    if (answerInput.value.trim().toLowerCase() === questions[currentQuestionIndex].answer.toLowerCase()) {
        score++;
    }
    currentQuestionIndex++;
    showQuestion();
}
